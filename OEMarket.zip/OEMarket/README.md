오늘도 우리 이웃과 함께, 오이마켓

********************
환경
********************

pom.xml에 추가.

1. windows10
2. sts(Version: 3.9.17.RELEASE)
3. tomcat9.0
4. oracle11g
5. lombok(lombok-1.18.24.jar)
6. jstl.jar
7. standard.jar
8. ojdbc6.jar
9. cos.jar

web.xml의 listener 삭제

